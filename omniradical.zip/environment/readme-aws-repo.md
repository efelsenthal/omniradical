# lambda-web-page

This component creates an API Gateway endpoint that is linked to a Lambda function that returns HTML (i.e. page can be viewed in a web browser)

## After deployment

After installing you can validate that all is working by navigating to API Gateway in your AWS Console and clicking the installed `lambda-web-page` API.  Click the `prod` stage and then follow the `Invoke Url` link at the top of the page 


     


